document.getElementById("loginForm").addEventListener("submit", function(event) {
  event.preventDefault();
  
  var username = document.getElementById("username").value;
  var password = document.getElementById("password").value;
  
  // Hier kun je je eigen inlogvalidatie implementeren
  
  if (username === "123" && password === "123") {
    showPage("homePage");
  } else {
    alert("Ongeldige inloggegevens!");
  }
});

function showPage(pageId) {
  var pages = document.getElementsByClassName("container");
  for (var i = 0; i < pages.length; i++) {
    pages[i].style.display = "none";
  }
  
  document.getElementById(pageId).style.display = "block";
}
